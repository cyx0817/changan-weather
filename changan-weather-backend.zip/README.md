# 长安有雨 · 私人云端语音

这个目录是单独部署的后台，不能直接由 GitHub Pages 运行。前端地址仍为 https://cyx0817.github.io/changan-weather/ 。

## 开通
1. 在 https://platform.minimax.cn/ 注册并登录，查看语音服务价格、余额和接口密钥。用户自行完成身份验证及付款。
2. 使用自己的 Cloudflare 账号部署此 Worker（包含 wrangler.toml 的 QUOTA Durable Object 绑定和 v1 migration）。官方 CLI：在本目录执行 `npx wrangler deploy`，登录及条款由用户完成。
3. 用 Cloudflare 的加密 Secret 设置 `MINIMAX_API_KEY` 和 `APP_TOKEN`。APP_TOKEN 应是独立生成的至少 32 字符随机口令，绝不能复用 MiniMax 密钥。也可执行 `npx wrangler secret put MINIMAX_API_KEY` / `npx wrangler secret put APP_TOKEN` 并交互输入。
4. 在网页“我的声音 → AI 音色 → 连接我的语音服务”中填写 Worker 的 HTTPS 地址和 APP_TOKEN。口令仅在当前页内存里使用；刷新需要重新连接，不写入 GitHub 或浏览器存储。
5. 选择本人或获同意的 MP3 / M4A / WAV（10 秒–5 分钟，本应用上限 5 MB），勾选同意上传，创建音色。然后点击“试听我的音色”完成首次合成，核对效果及平台计费提示。

## 数据与限制
- 录音经 Worker 发往 MiniMax；Worker 不持久保存录音，MiniMax 中的素材与音色需在其账号管理。网页“移除此音色”仅删除本地关联，不声称删除云端素材。
- 音色编号保存在当前浏览器；口令不持久保存。其他人需用自己的后台与账户，不能从公共网页获得你的口令。
- 每个后台每天（UTC）最多 3 次克隆、30 次播报，每次最多 500 字；失败请求也计入保护额度。这不是费用上限，仍以平台实际计费为准。
- 仅对已连接用户启用；未连接时明确提示，不将系统语音冒充克隆音色。
- 网络音频可能被手机拦截自动播放；页面提供音频播放器供手动播放。
- 当前只提供点击播报，关闭网页后不会主动语音提醒。

## 已验证范围
使用模拟服务验证了鉴权、来源、额度、输入、合成响应和错误处理。未配置真实账户和样本前，不能声称已验证真实音色效果或已启用线上克隆。

官方文档：
- https://platform.minimax.cn/docs/api-reference/voice-cloning-clone
- https://platform.minimax.cn/docs/api-reference/file-management-upload
- https://platform.minimax.cn/docs/api-reference/speech-t2a-http
