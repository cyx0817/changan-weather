// Deploy separately from GitHub Pages. Secrets belong in Worker settings only.
const API='https://api.minimax.cn/v1';
const MAX_AUDIO=5*1024*1024;
const error=(message,status=400)=>Object.assign(new Error(message),{status});
async function boundedBody(request,limit){
 if(Number(request.headers.get('Content-Length'))>limit)throw error('文件或请求太大。',413);
 const reader=request.body?.getReader();if(!reader)return new Uint8Array();
 const parts=[];let total=0;
 while(true){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>limit){await reader.cancel();throw error('文件或请求太大。',413);}parts.push(value);}
 const bytes=new Uint8Array(total);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}return bytes;
}
async function provider(path,body,key,fetcher){
 const form=body instanceof FormData;
 const r=await fetcher(API+path,{method:'POST',headers:{Authorization:`Bearer ${key}`,...(!form?{'Content-Type':'application/json'}:{})},body:form?body:JSON.stringify(body),signal:AbortSignal.timeout(90000)});
 if(!r.ok)throw error('语音平台暂不可用，请检查账户余额和服务权限。',502);
 const j=await r.json();if(j.base_resp?.status_code!==0)throw error('语音平台未完成请求，请检查余额、音频质量或音色状态。',502);return j;
}
export async function handleRequest(request,env,fetcher=fetch){
 const origin=request.headers.get('Origin');
 const headers={'Access-Control-Allow-Origin':env.ALLOWED_ORIGIN||'https://cyx0817.github.io','Vary':'Origin','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
 const json=(body,status=200)=>Response.json(body,{status,headers});
 if(origin!==env.ALLOWED_ORIGIN)return json({error:'此来源未获授权。'},403);
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{...headers,'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Authorization, Content-Type','Access-Control-Max-Age':'600'}});
 if(!env.MINIMAX_API_KEY||!env.APP_TOKEN||env.APP_TOKEN.length<32||!env.QUOTA)return json({error:'云端语音尚未配置完成。'},503);
 if(request.headers.get('Authorization')!==`Bearer ${env.APP_TOKEN}`)return json({error:'访问口令不正确，请重新连接。'},401);
 const path=new URL(request.url).pathname;
 if(path==='/health'&&request.method==='GET')return json({ready:true,provider:'MiniMax',dailySpeakLimit:30,dailyCloneLimit:3});
 if(request.method!=='POST'||!['/clone','/speak'].includes(path))return json({error:'接口不存在。'},404);
 try{
  let input;
  if(path==='/clone'){
   const bytes=await boundedBody(request,MAX_AUDIO+16384);
   input=await new Response(bytes,{headers:{'Content-Type':request.headers.get('Content-Type')||''}}).formData();
   const sample=input.get('sample');
   if(input.get('consent')!=='yes')throw error('请先确认你拥有录音使用授权，并同意发送至 MiniMax。');
   if(!(sample instanceof File)||!sample.size||sample.size>MAX_AUDIO||!(/\.(mp3|m4a|wav)$/i.test(sample.name)))throw error('请选择不超过 5 MB 的 MP3、M4A 或 WAV 录音。');
  }else{
   input=JSON.parse(new TextDecoder().decode(await boundedBody(request,8192)));
   if(typeof input.text!=='string'||!input.text.trim()||input.text.length>500)throw error('播报内容应为 1–500 字。');
   if(typeof input.voiceId!=='string'||!/^changan_[A-Za-z0-9]{8,64}$/.test(input.voiceId))throw error('请先创建此应用的个人音色。');
  }
  const quota=await env.QUOTA.get(env.QUOTA.idFromName('owner')).fetch(new Request('https://quota/check',{method:'POST',body:path}));
  if(!quota.ok)throw error('今天的使用次数已到上限，请明天再试。',429);
  if(path==='/clone'){
   const form=new FormData();form.append('purpose','voice_clone');form.append('file',input.get('sample'));
   const upload=await provider('/files/upload',form,env.MINIMAX_API_KEY,fetcher);
   if(!upload.file?.file_id)throw error('录音上传未完成。',502);
   const voiceId='changan_'+crypto.randomUUID().replaceAll('-','');
   await provider('/voice_clone',{file_id:upload.file.file_id,voice_id:voiceId,need_noise_reduction:true,need_volume_normalization:true},env.MINIMAX_API_KEY,fetcher);
   return json({voiceId});
  }
  const result=await provider('/t2a_v2',{model:'speech-2.8-hd',text:input.text,stream:false,language_boost:'Chinese',output_format:'hex',voice_setting:{voice_id:input.voiceId,speed:.95,vol:1,pitch:0},audio_setting:{sample_rate:32000,bitrate:128000,format:'mp3',channel:1}},env.MINIMAX_API_KEY,fetcher);
  const hex=result.data?.audio;
  if(typeof hex!=='string'||hex.length<2||hex.length>16*1024*1024||hex.length%2||!/^[\da-f]+$/i.test(hex))throw error('语音平台没有返回有效音频。',502);
  const audio=Uint8Array.from(hex.match(/.{2}/g),x=>parseInt(x,16));
  return new Response(audio,{headers:{...headers,'Content-Type':'audio/mpeg'}});
 }catch(e){return json({error:e.status?e.message:e.name==='TimeoutError'?'语音服务响应超时，请稍后再试。':'请求未完成，请检查音频或稍后重试。'},e.status||502);}
}
export default {fetch(request,env){return handleRequest(request,env);}};

// One durable counter per installation: atomic daily limits across all devices.
export class VoiceQuota{
 constructor(state){this.state=state;}
 async fetch(request){
  const route=await request.text(),day=new Date().toISOString().slice(0,10),field=route==='/clone'?'clone':'speak',limit=field==='clone'?3:30;
  const allowed=await this.state.storage.transaction(async tx=>{
   let counters=await tx.get('daily');if(counters?.day!==day)counters={day,clone:0,speak:0};
   if(counters[field]>=limit)return false;counters[field]++;await tx.put('daily',counters);return true;
  });
  return Response.json({ok:allowed},{status:allowed?200:429});
 }
}
